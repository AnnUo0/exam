﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp222.Pages;

namespace WpfApp222.Pages
{
    /// <summary>
    /// Логика взаимодействия для AuthPage.xaml
    /// </summary>
    public partial class AuthPage : Page
    {
        public AuthPage()
        {
            InitializeComponent();
        }

        private void ButtonNext_Click(object sender, RoutedEventArgs e)
        {
            App.Global=TB_Login.Text;
            var currentUser = App.Context.User.FirstOrDefault(x=>x.Login==TB_Login.Text && x.Password==PB_password.Password);
            if (currentUser != null)
            {

                App.CurrentUser = currentUser;
                if (App.CurrentUser.ID_role == 1)
                {
                    NavigationService.Navigate(new MainMenu());
                }

                else if (App.CurrentUser.ID_role == 2)
                {
                    NavigationService.Navigate(new ManagerPage());
                }

                else if (App.CurrentUser.ID_role == 3)
                {
                    NavigationService.Navigate(new OperatorMenuPage());
                }
            }
            

            else
            {
                MessageBox.Show("Please try again","Error" );
            }


        }

        private void HL_Reg_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new LogPage());
        }
    }
}
