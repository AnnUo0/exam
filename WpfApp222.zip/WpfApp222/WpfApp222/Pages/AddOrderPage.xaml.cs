﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace WpfApp222.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddOrderPage.xaml
    /// </summary>
    public partial class AddOrderPage : Page
    {
    

        private Order _currentOrder = new Order();
        public AddOrderPage()
        {
            InitializeComponent();

            DataContext = _currentOrder;

           Equipment_cb.ItemsSource= App.Context.Equipment.ToList();
            Defect_cb.ItemsSource=App.Context.Defect.ToList();  
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Frame());
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
             if(_currentOrder.ID_order==0)

             {
                App.GetContext.Order.Add(_currentOrder);

                try
                {
                    App.GetContext.SaveChanges();
                    MessageBox.Show("Order saved", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.NavigationService.Navigate(new Frame());
                }
                catch 
                {
                    MessageBox.Show("Error", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
             }
         


        }

        private void Equipment_cb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
